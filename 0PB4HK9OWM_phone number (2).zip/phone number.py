def maskify(mobile_number):
    if len(mobile_number) <= 3:
        return mobile_number
    else:
        masked_part = "#" * (len(mobile_number) - 3)
        last_digits = mobile_number[-3:]
        return masked_part + last_digits
mobile_number = "9573870459"
masked_mobile = maskify(mobile_number)
print(masked_mobile)